//
//  ImageCollectionViewCell.swift
//  TestViewController
//
//  Created by pratap shaik on 09/02/22.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var image: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

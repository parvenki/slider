//
//  ViewController.swift
//  TestViewController
//
//  Created by pratap shaik on 09/02/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var testView: UIView!
    var ttt: ImageCollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        var cgrect = CGRect(x:0,y:0,width: 400,height: 250)
        ttt = ImageCollectionView(frame:cgrect)
        self.view.addSubview(ttt)
    }


}


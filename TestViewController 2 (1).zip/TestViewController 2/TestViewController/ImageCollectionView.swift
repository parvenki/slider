//
//  ImageCollectionView.swift
//  TestViewController
//
//  Created by pratap shaik on 09/02/22.
//

import UIKit

class ImageCollectionView: UIView  {
    @IBOutlet weak var lbl: UILabel!
    
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var contentView: UIView!
    
    var imageArray = ["image1","image1","image1","image1"]

    var nibName: String {
        return String(describing: type(of: self))
    }
    
    //MARK:
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        loadViewFromNib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        loadViewFromNib()
    }
    
    //MARK:
    func loadViewFromNib() {
        
        contentView = Bundle.main.loadNibNamed(nibName, owner: self, options: nil)?[0] as! UIView
        contentView.frame = self.frame
        contentView.backgroundColor = .white
        addSubview(contentView)
        let nib = UINib(nibName: "ImageCollectionViewCell", bundle: nil)
        collectionView?.register(nib, forCellWithReuseIdentifier: "ImageCollectionViewCell")
          self.backgroundColor = .white
          collectionView?.delegate = self
          collectionView?.dataSource = self
        pageControl.currentPage = 0
        pageControl.numberOfPages = imageArray.count
//        initCollectionView()
    }
//    private func initCollectionView() {
//      let nib = UINib(nibName: "ImageCell", bundle: nil)
//      collectionView?.register(nib, forCellWithReuseIdentifier: "ImageCell")
//        self.backgroundColor = .red
//        collectionView?.delegate = self
//        collectionView?.dataSource = self
//        lbl.text = "fhskjfjkjksjfhjksadhjkfhjkadsk"
//    }
  /*
    private func initCollectionView() {
      let nib = UINib(nibName: "ImageCell", bundle: nil)
      collectionView?.register(nib, forCellWithReuseIdentifier: "ImageCell")
        self.backgroundColor = .red
        collectionView?.delegate = self
        collectionView?.dataSource = self
        lbl.text = "fhskjfjkjksjfhjksadhjkfhjkadsk"
    }
    
    
    
    //UICollectionViewDelegateFlowLayout methods
    private func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAtIndex section: Int) -> CGFloat
    {
        
        return 4;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat
    {
        
        return 1;
    }
    //UICollectionViewDatasource methods
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return 2
    }
    

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCell", for: indexPath as IndexPath) as! ImageCollectionViewCell
    
//        cell.backgroundColor = self.randomColor()
        
        
        return cell
    }
    
*/

}


extension ImageCollectionView:UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCollectionViewCell", for: indexPath as IndexPath) as! ImageCollectionViewCell
        let name = imageArray[indexPath.row]
        cell.image.image =  UIImage(named:name)
       return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        pageControl.currentPage = indexPath.row
    }
    
}
